AUTHOR: V.K.VIEKASH
LAST UPDATED ON: 22/05/2020 

Pre requisites to run the code:
	- python 3.5 or 3.5+
	Should have installed the following packages:(latest version)
	- PIL
	- numpy
	- Opencv
	- tkinter

Modifications to be made before running the code:
	- in line 14 of the code change the variable saving_image_number during every new run of the code, to the number that you want to give as name to the new image that you are going to save next

Requirements:
	- The image that you are going to load should be similar to HC_18 dataset images(dimensions: (540,800,3) and PNG format) 

Running the code:
	- After the pre requisites,requirements are satisfied and modifications are done execute the code and wait for a while. I t might take around 1-2 mins to open if you are running the code for first time in your device.

Output:
	- once you press the save segmentation button the output will be saved in the directory you choose in PNG format.
	- The output images will be encoded by pixel intesnity values are as follows:
                     -> external class = 0
		     -> tissue_1(as named in the tool) 1x18=18
		     -> tissue_2(as named in the tool) 2x18=36
		     -> tissue_3(as named in the tool) 3x18=54	
		     -> tissue_4(as named in the tool) 4x18=72
		     -> tissue_5(as named in the tool) 5x18=90
		     -> tissue_6(as named in the tool) 6x18=108
		     -> tissue_7(as named in the tool) 7x18=126
		     -> tissue_8(as named in the tool) 8x18=144
		     -> tissue_9(as named in the tool) 9x18=162
		     -> tissue_10(as named in the tool) 10x18=180
		     -> tissue_11(as named in the tool) 11x18=198
		     -> tissue_12(as named in the tool) 12x18=216
		     -> tissue_13(as named in the tool) 13x18=234
		     -> tissue_14(as named in the tool) 14x18=252

	- Maximum 14 different tissue segmentations can be made with this tool 

NOTE: number 18 was chosen as a multiple to enhance the pixel values and display them between the range 0 and 252











					
